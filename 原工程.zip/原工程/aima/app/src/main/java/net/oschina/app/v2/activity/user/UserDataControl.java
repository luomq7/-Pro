package net.oschina.app.v2.activity.user;

import net.oschina.app.v2.model.User;

/**
 * Created by Tonlin on 2015/8/21.
 */
public interface UserDataControl {

    void setUserInfo(User user);
}
