package net.oschina.app.v2.activity.news.fragment;

import net.oschina.app.v2.emoji.EmojiFragment;

public interface EmojiFragmentControl {

	public void setEmojiFragment(EmojiFragment fragment);
}
