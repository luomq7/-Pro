package net.oschina.app.v2.model;

import java.io.Serializable;
import java.util.List;

public interface ListEntity extends Serializable {

	public List<?> getList();

}
