package net.oschina.app.v2.base;

public interface VisibilityControl {

	public abstract boolean isVisible();
}
