package net.oschina.app.v2.activity.news;

public interface ToolbarEmojiVisiableControl {

	public void toggleToolbarEmoji();
}
