package net.oschina.app.v2.model;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import java.util.List;

/**
 * LikeTweetList.java
 * 
 * @author 火蚁(http://my.oschina.net/u/253900)
 *
 * @data 2015-4-10 上午10:11:48
 */
@SuppressWarnings("serial")
@XStreamAlias("oschina")
public class TweetLikeList implements ListEntity {

    @XStreamAlias("likeList")
    private List<TweetLike> list;
    
    @Override
    public List<TweetLike> getList() {
	// TODO Auto-generated method stub
	return list;
    }

    public void setList(List<TweetLike> list) {
        this.list = list;
    }

}

