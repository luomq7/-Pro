package net.oschina.app.v2.activity.tweet;

/**
 * Created by Tonlin on 2015/8/18.
 */
public interface TweetTabClickListener {
    void onTabChanged(int idx);
    void onCommentClick();
    void onLikeClick();
    void onRefreshData(int idx);
}
