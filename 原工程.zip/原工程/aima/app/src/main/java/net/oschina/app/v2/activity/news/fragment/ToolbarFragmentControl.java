package net.oschina.app.v2.activity.news.fragment;


public interface ToolbarFragmentControl {

	public void setToolBarFragment(ToolbarFragment fragment);
}
